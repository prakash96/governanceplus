package com.bhanu.autoreview.handlers;

import java.io.File;
import java.util.Set;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.handlers.HandlerUtil;

import com.bhanu.autoreview.logic.MuleRuleValidatorMojo;
import com.bhanu.autoreview.model.Violation;

public class ReviewHandler extends AbstractHandler {

    @Override
    public Object execute(ExecutionEvent event) throws ExecutionException {

    	// Get the selection from the active workbench
    	ISelection selection = PlatformUI.getWorkbench()
    	        .getActiveWorkbenchWindow()
    	        .getSelectionService()
    	        .getSelection();

    	IProject project = null;

    	if (selection == null || selection.isEmpty()) {
            MessageDialog.openInformation(
                    HandlerUtil.getActiveShell(event),
                    "Review Project",
                    "Please select a project first.");
            return null;
        }

    	if (selection instanceof IStructuredSelection) {
    	    Object firstElement = ((IStructuredSelection) selection).getFirstElement();

    	    if (firstElement instanceof IProject) {
    	        project = (IProject) firstElement;
    	    } else if (firstElement instanceof IAdaptable) {
    	        project = ((IAdaptable) firstElement).getAdapter(IProject.class);
    	    }
    	}

        if (project == null || !project.isOpen()) {
            MessageDialog.openInformation(
                    HandlerUtil.getActiveShell(event),
                    "Review Project",
                    "Please select a project first.");
            return null;
        }

        // Restrict to src/main/mule folder
        IFolder muleFolder = project.getFolder("src/main/mule");
        if (!muleFolder.exists()) {
            MessageDialog.openInformation(
                    HandlerUtil.getActiveShell(event),
                    "Review Project",
                    "No src/main/mule folder found in project " + project.getName());
            return null;
        }

        IFile rulesFile = project.getFile("rules.json");
        if (!rulesFile.exists()) {
            MessageDialog.openInformation(
                    HandlerUtil.getActiveShell(event),
                    "Review Project",
                    "No rules.json found in project " + project.getName());
            return null;
        }

        IPath location = project.getLocation();  // workspace absolute path
        File folder = location.toFile();           // convert to java.io.File
        
        try {
			Set<Violation> violations = new MuleRuleValidatorMojo().execute(folder, rulesFile.getLocation().toString());
			if(violations == null || violations.size() == 0) {
				MessageDialog.openInformation(
		                HandlerUtil.getActiveShell(event),
		                "Review Project",
		                "All good");
				return null;
			}
			else {
				StringBuilder messageBuilder = new StringBuilder();
				for(Violation v: violations) {
					messageBuilder.append("\n\n\t" + v.getRuleId()
                            + " : "
                            + v.getMessage()
                            + " ("
                            + v.getFile()
                            + ": " + v.getLine() + ") \t\n\n");
				}
				
				ScrollableMessageDialog dialog = new ScrollableMessageDialog(Display.getDefault().getActiveShell(), messageBuilder.toString());
				dialog.open();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
			MessageDialog.openInformation(
	                HandlerUtil.getActiveShell(event),
	                "Review Project",
	                e.getMessage());
			
		}        
        
        return null;
        
    }
}