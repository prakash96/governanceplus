package com.bhanu.autoreview.handlers;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class ScrollableMessageDialog extends Dialog {

    private String message;

    public ScrollableMessageDialog(Shell parentShell, String message) {
        super(parentShell);
        this.message = message;
    }

    @Override
    protected Control createDialogArea(Composite parent) {
        Composite container = (Composite) super.createDialogArea(parent);
        container.setLayout(new FillLayout());

        // Scrollable Text area
        Text text = new Text(container, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL | SWT.MULTI);
        text.setEditable(false);
        text.setText(message);

        return container;
    }

    @Override
    protected void configureShell(Shell newShell) {
        super.configureShell(newShell);
        newShell.setText("Code Review Violations");
        newShell.setSize(600, 400); // adjust size as needed
    }
}