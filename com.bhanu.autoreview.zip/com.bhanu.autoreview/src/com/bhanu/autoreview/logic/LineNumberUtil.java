package com.bhanu.autoreview.logic;
import javax.xml.stream.*;
import java.io.File;
import java.io.FileInputStream;

public class LineNumberUtil {

    public static int findLineNumber(File file, String tagName, int targetIndex) {
        try {
            XMLInputFactory factory = XMLInputFactory.newInstance();
            XMLStreamReader reader = factory.createXMLStreamReader(new FileInputStream(file));

            int currentIndex = 0;

            while (reader.hasNext()) {
                int event = reader.next();

                if (event == XMLStreamConstants.START_ELEMENT) {
                    String currentTag = reader.getLocalName();

                    if (currentTag.equals(tagName)) {
                        currentIndex++;

                        if (currentIndex == targetIndex) {
                            return reader.getLocation().getLineNumber();
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return -1;
    }
}