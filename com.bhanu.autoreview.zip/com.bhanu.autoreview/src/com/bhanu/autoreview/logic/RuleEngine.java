
package com.bhanu.autoreview.logic;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.bhanu.autoreview.model.RuleConfig;
import com.bhanu.autoreview.model.Violation;

public class RuleEngine {

    public Set<Violation> validate(File projectDir, String rulesPath) throws Exception {

        RuleLoader loader = new RuleLoader();
        RuleConfig config = loader.load(rulesPath);

        XPathEvaluator evaluator = new XPathEvaluator();

        Set<Violation> violations = new LinkedHashSet<>();

        Path muleDir = Paths.get(projectDir.getAbsolutePath(), "src/main/mule");

        if (!Files.exists(muleDir))
            return violations;

        List<File> allXmlFiles = new ArrayList<>();
        Files.walk(muleDir)
                .filter(p -> p.toString().endsWith(".xml"))
                .forEach(path -> {

                	allXmlFiles.add(path.toFile());
                });
        
        for(File xmlFile: allXmlFiles){
        	try {
            	
            	
                violations.addAll(
                        evaluator.evaluate(
                                xmlFile,
                                config.getRules(), allXmlFiles
                        )
                );

            } catch (Exception e) {

                e.printStackTrace();
            }

        }
        
        File pomFile = new File(projectDir, "pom.xml");
        if(pomFile.exists()) {
        	violations.addAll(PomDependencyValidator.validate(pomFile, config.getPomRules()));
        }
        
        return violations;
    }
}
