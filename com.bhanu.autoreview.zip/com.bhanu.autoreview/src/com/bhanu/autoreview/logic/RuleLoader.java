
package com.bhanu.autoreview.logic;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.bhanu.autoreview.model.PomRule;
import com.bhanu.autoreview.model.Rule;
import com.bhanu.autoreview.model.RuleConfig;

public class RuleLoader {

	public RuleConfig load(String filePath) throws Exception {

		// Read JSON file
		String content = new String(Files.readAllBytes(Paths.get(filePath)));
		JSONObject json = new JSONObject(content);

		// Get rules array
		JSONArray rulesArray = json.getJSONArray("rules");

		JSONArray pomRulesArray = json.getJSONArray("pomRules");
		List<Rule> ruleList = new ArrayList<>();

		List<PomRule> pomRuleList = new ArrayList<>();
		for (int i = 0; i < rulesArray.length(); i++) {
			JSONObject obj = rulesArray.getJSONObject(i);

			Rule rule = new Rule(obj.optString("id"), obj.optString("category"), obj.optString("severity", "INFO"),
					obj.optString("description"), obj.optString("xpath"), obj.optString("usageAttribute", null), obj.optString("usagePattern"));

			ruleList.add(rule);
		}
		
		for (int i = 0; i < pomRulesArray.length(); i++) {
			JSONObject obj = pomRulesArray.getJSONObject(i);

			PomRule rule = new PomRule(obj.optString("artifactId"), obj.optString("minVersion"));

			pomRuleList.add(rule);
		}

		return new RuleConfig(ruleList, pomRuleList);
	}
}
