
package com.bhanu.autoreview.model;

import java.util.List;

public class RuleConfig {

    public RuleConfig(List<Rule> rules, List<PomRule> pomRules) {
		super();
		this.rules = rules;
		this.pomRules = pomRules;
	}

	private List<Rule> rules;

	private List<PomRule> pomRules;
	
    public List<PomRule> getPomRules() {
		return pomRules;
	}

	public void setPomRules(List<PomRule> pomRules) {
		this.pomRules = pomRules;
	}

	public List<Rule> getRules() { return rules; }

    public void setRules(List<Rule> rules) { this.rules = rules; }
}
