package com.bhanu.autoreview.model;

public class PomRule {
	String artifactId;
	String minVersion;

	public PomRule(String artifactId, String minVersion) {
		this.artifactId = artifactId;
		this.minVersion = minVersion;
	}

	public String getArtifactId() {
		return artifactId;
	}

	public void setArtifactId(String artifactId) {
		this.artifactId = artifactId;
	}

	public String getMinVersion() {
		return minVersion;
	}

	public void setMinVersion(String minVersion) {
		this.minVersion = minVersion;
	}

}
